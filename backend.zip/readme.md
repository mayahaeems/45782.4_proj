# Supermarket Web Application

## Overview
This project is a full-featured supermarket web application built with **Flask (Python) and RESTful APIs**.  
It provides a complete shopping experience for both users and administrators, including product browsing, cart management, checkout, and order history.

The system is designed with a **clean backend architecture**, clear separation of concerns, and strong data consistency rules.

---

## Features

### User Features
- User registration and login.
- JWT-based authentication.
- Browse products and categories with images.
- Add, update, or remove items from the shopping cart.
- **Only one active cart per user**.
- Visual alerts for:
  - Price changes
  - Out-of-stock products
  - Inactive products
- Checkout with PayPal or credit card.
- View personal order history.
- Delete own account (soft delete) while preserving order history.

---

### Admin Features
- Create, update, and delete products.
- Manage categories (name, description, **single image**).
- Upload images:
  - Products → multiple images (one main image)
  - Categories → exactly one image
- Change user roles (USER → ADMIN).
- View and manage all users.
- Monitor system changes using logs:
  - Price changes
  - Quantity updates
  - Active / inactive status
  - Name, description, and image updates
  - Product–category relationship changes

---

## Data Models

### Users
- `id`
- `full_name`
- `email`
- `password_hash`
- `role` (USER / ADMIN)
- `is_active`
- `created_at`
- `updated_at`

---

### Categories
- `id`
- `name`
- `description`
- `created_at`
- `updated_at`

**Rules:**
- Each category must have **exactly one image**.
- A category can contain multiple products.

---

### Products
- `id`
- `name`
- `description`
- `price`
- `quantity`
- `is_active`
- `created_at`
- `updated_at`

**Rules:**
- A product must belong to **at least one category**.
- A product may belong to multiple categories.
- Products can have multiple images (one main image).

---

### Images (Polymorphic)
- `id`
- `entity_id`
- `entity_type` (`product` / `category`)
- `image_url`
- `is_main`
- `created_at`

**Rules:**
- Category → exactly **1 image**
- Product → multiple images allowed, **one main image**

---

### Cart & CartItems
- Each user has **only one active cart**.
- Cart is stored in:
  - Database (backend source of truth)
  - Local storage (frontend cache)
- Tracks:
  - `quantity`
  - `original_quantity` (used to detect inventory changes)

**Behavior:**
- If product price or availability changes:
  - Item is highlighted
  - User must confirm or update cart
- Ordering with outdated prices is **not allowed**.

---

### Orders & OrderItems
- Created from the active cart.
- Stores prices **at the time of purchase**.
- Fields:
  - `payment_status` (pending / paid / canceled)
  - `payment_method` (PayPal / Credit Card)
  - `total_price`
- Users can view full order history.

---

### Logs

#### InventoryLog
Tracks all product changes:
- Price
- Quantity
- Active / inactive status
- Name & description updates
- Image changes
- Product deletion

#### CategoryLog
Tracks all category changes:
- Name & description updates
- Image changes
- Product associations
- Category deletion

Logs are created automatically and used for auditing and admin monitoring.

---

## System Rules & Behavior

- Each user can have **only one active cart**.
- Cart data is always validated against current product data.
- Users cannot checkout:
  - Inactive products
  - Products with changed prices
- Deleted users are **soft deleted** (`is_active = false`).
- Order history is **never removed**.
- Admin actions are fully logged.

---

## Technology Stack

### Backend
- **Python**
- **Flask**
- Flask-RESTful / Flask Blueprints
- Flask-JWT-Extended (JWT Authentication)
- SQLAlchemy (ORM)
- Marshmallow (Schemas / Serialization)

### Frontend
- JavaScript (JS)
- React / Vue / Angular (optional)

### Database
- PostgreSQL / MySQL / SQLite

### File Uploads
- Pillow
- Multipart file uploads

### Other
- Docker & Docker Compose (optional)
- Node.js scripts (optional server-side automation)

---

## Installation

```bash
git clone <repository-url>
cd supermarket/backend

python -m venv venv
source venv/bin/activate        # Linux / macOS
# or
venv\Scripts\activate           # Windows

pip install -r requirements.txt
python run.py
